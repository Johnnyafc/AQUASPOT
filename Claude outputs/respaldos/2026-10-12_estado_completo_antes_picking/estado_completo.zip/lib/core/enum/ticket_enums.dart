// lib/features/tickets/domain/entities/ticket_enums.dart

enum Sede { DURAN, EL_GUABO, NINGUNO }

enum TipoGarantia {
  pendiente,      // Estado inicial en la UI
  servicio,       // Garantía sobre un trabajo de reparación previo
  maquinaNueva,   // Garantía de fábrica por equipo recién vendido
  noAplica        // Para tickets que no son garantía (Venta, Alquiler, etc.)
}

/// Define el centro de costos o entidad que absorbe el valor operativo.
enum ResponsableFacturacion {
  pendiente,      // Aún no calculado
  cliente,        // Facturación normal al cliente final
  agrispotsa,     // Absorbido por la matriz AGRISPOTSA (Ej: Garantía máquina nueva)
  tallerInterno,  // Absorbido por el taller (Ej: Garantía de servicio)
  noAplica
}

/// Formatea de forma segura y consistente el responsable de facturación
String formatearResponsableFacturacion(String? raw) {
  if (raw == null || raw.trim().isEmpty) return 'NO DEFINIDO';
  final lower = raw.trim().toLowerCase();
  if (lower == 'agripotsa' || lower == 'agrispotsa') return 'AGRISPOTSA';
  if (lower == 'tallerinterno') return 'TALLER INTERNO';
  if (lower == 'cliente') return 'CLIENTE';
  if (lower == 'pendiente') return 'PENDIENTE';
  if (lower == 'noaplica') return 'NO APLICA';
  return raw.toUpperCase();
}

enum TipoEquipo { Caracol, Cosechadora, Contador, Otros}

enum Prioridad { baja, media, alta }

enum EstadoTicket { 
  creado, 
  enCamino,            
  recepcionFisica,
  revisionGarantia,
  cotizandoRepuesto,   // Venta de Repuesto sin stock: Compras cotiza
  comercial,
  cotizado,
  costos,
  compras,
  bodega,
  procesoTrabajo,
  validacionFacturacion,
  entrega,
  finalizado,           // Cerrado y correo enviado
  anulado 
}

enum TipoRequerimiento {
  ventaRepuesto,
  alquilerPrueba,
  reparacion,
  reclamoGarantia,
  ventaMaquina,
  ninguno
}

enum LugarAtencion {
  taller,
  campo,
  pendiente, // ⚙️ Clave para mantener el submenú abierto
  noAplica
}

// 🆕 Medio de contacto para Venta de Repuesto (reemplaza al "Lugar de
// recepción" / Sede en ese flujo, ya que no hay equipo que recibir).
enum MedioContacto {
  whatsapp,
  correo,
  celular,
}

extension EstadoTicketExtension on EstadoTicket {
  String get nombreLegible {
    switch (this) {
      case EstadoTicket.creado:
        return 'Creado';
      case EstadoTicket.enCamino:
        return 'En camino';
      case EstadoTicket.recepcionFisica:
        return 'Evaluación técnica';
      case EstadoTicket.revisionGarantia:
        return 'Revisión garantía';
      case EstadoTicket.cotizandoRepuesto:
        return 'Cotizando repuesto';
      case EstadoTicket.comercial:
        return 'Comercial';
      case EstadoTicket.cotizado:
        return 'Cotizado';
      case EstadoTicket.costos:
        return 'Costos';
      case EstadoTicket.compras:
        return 'Compras';
      case EstadoTicket.bodega:
        return 'Bodega';
      case EstadoTicket.procesoTrabajo:
        return 'Proceso de trabajo';
      case EstadoTicket.validacionFacturacion:
        return 'Revisión de pagos';
      case EstadoTicket.entrega:
        return 'Entrega';
      case EstadoTicket.finalizado:
        return 'Finalizado';
      case EstadoTicket.anulado:
        return 'Anulado';
    }
  }

  String get nombreMayusculas => nombreLegible.toUpperCase();
}