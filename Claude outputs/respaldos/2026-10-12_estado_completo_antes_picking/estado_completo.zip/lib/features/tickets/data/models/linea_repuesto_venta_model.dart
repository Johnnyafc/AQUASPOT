import '../../domain/entities/linea_repuesto_venta_entity.dart';

class LineaRepuestoVentaModel extends LineaRepuestoVentaEntity {
  const LineaRepuestoVentaModel({
    required super.codigo,
    required super.descripcion,
    required super.unidad,
    required super.cantidad,
    super.stockDisponibleAlEvaluar,
  });

  factory LineaRepuestoVentaModel.fromJson(Map<String, dynamic> json) {
    return LineaRepuestoVentaModel(
      codigo: json['codigo']?.toString() ?? '',
      descripcion: json['descripcion']?.toString() ?? '',
      unidad: json['unidad']?.toString() ?? '',
      cantidad: (json['cantidad'] as num?)?.toDouble() ?? 0,
      stockDisponibleAlEvaluar: (json['stockDisponibleAlEvaluar'] as num?)?.toDouble(),
    );
  }

  factory LineaRepuestoVentaModel.fromEntity(LineaRepuestoVentaEntity entity) {
    return LineaRepuestoVentaModel(
      codigo: entity.codigo,
      descripcion: entity.descripcion,
      unidad: entity.unidad,
      cantidad: entity.cantidad,
      stockDisponibleAlEvaluar: entity.stockDisponibleAlEvaluar,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'codigo': codigo,
      'descripcion': descripcion,
      'unidad': unidad,
      'cantidad': cantidad,
      'stockDisponibleAlEvaluar': stockDisponibleAlEvaluar,
    };
  }
}
