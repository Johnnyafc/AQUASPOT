// lib/features/tickets/domain/entities/linea_repuesto_venta_entity.dart
//
// Una línea de repuesto dentro de una Venta de Repuesto: una "foto" del
// ítem de inventario elegido (código, descripción, unidad) más la
// cantidad pedida. Es una copia congelada al momento de agregarla, no una
// referencia viva al catálogo -- así el registro de la venta no cambia si
// después se edita o se borra ese ítem del inventario.

import 'package:equatable/equatable.dart';

class LineaRepuestoVentaEntity extends Equatable {
  final String codigo;
  final String descripcion;
  final String unidad;
  final double cantidad;

  // Stock neto que había en inventario al momento de registrar/evaluar el
  // requerimiento (null = todavía no se ha evaluado). Con esto se decide
  // si el requerimiento pasa a Comercial o a Cotizando Repuesto, y Compras
  // ve en rojo las líneas que no alcanzan.
  final double? stockDisponibleAlEvaluar;

  const LineaRepuestoVentaEntity({
    required this.codigo,
    required this.descripcion,
    required this.unidad,
    required this.cantidad,
    this.stockDisponibleAlEvaluar,
  });

  bool get tieneStockSuficiente => (stockDisponibleAlEvaluar ?? 0) >= cantidad;

  /// Cantidad que no cubre el stock (0 si alcanza).
  double get cantidadFaltante {
    final faltante = cantidad - (stockDisponibleAlEvaluar ?? 0);
    return faltante > 0 ? faltante : 0;
  }

  LineaRepuestoVentaEntity copyWith({double? cantidad, double? stockDisponibleAlEvaluar}) {
    return LineaRepuestoVentaEntity(
      codigo: codigo,
      descripcion: descripcion,
      unidad: unidad,
      cantidad: cantidad ?? this.cantidad,
      stockDisponibleAlEvaluar: stockDisponibleAlEvaluar ?? this.stockDisponibleAlEvaluar,
    );
  }

  @override
  List<Object?> get props => [codigo, descripcion, unidad, cantidad, stockDisponibleAlEvaluar];
}
