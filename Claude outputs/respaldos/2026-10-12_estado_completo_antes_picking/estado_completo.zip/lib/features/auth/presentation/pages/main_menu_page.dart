// lib/features/tickets/presentation/pages/main_menu_page.dart

import 'package:aquaspot_postventa/core/enum/segmento_operativo.dart';
import 'package:aquaspot_postventa/features/clientes/presentation/pages/gestion_clientes_page.dart';
import 'package:aquaspot_postventa/features/clientes/presentation/widgets/registro_cliente_bottom_sheet.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/bloc/ticket_bloc.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/bloc/ticket_event.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/BandejaBodegaPage.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/BandejaCostosPage.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/BandejaProformasEnviadasPage.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/BandejaRecepcionGuaboPage.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/BandejaTrabajosPage.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/ValidacionFacturacionPage.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/bandeja_comercial_Page.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/bandeja_compras_page.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/bandeja_entregas_page.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/bandeja_revisiones_garantias_page.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/bandeja_despacho_bodega_page.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/bandeja_recepcion_bodega_page.dart';
import 'package:aquaspot_postventa/features/inventario/presentation/pages/gestion_stock_bodega_page.dart';
import 'package:aquaspot_postventa/features/catalogo/presentation/pages/gestion_catalogo_actividades_page.dart';
import 'package:aquaspot_postventa/features/catalogo/presentation/pages/revision_codigos_plan_maestro_page.dart';
import 'package:aquaspot_postventa/features/tecnicos/presentation/pages/gestion_tecnicos_page.dart';
import 'package:aquaspot_postventa/features/fallas/presentation/pages/gestion_metricas_fallas_page.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/bandeja_fallas_pendientes_page.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/modificar_ticket_page.dart';
import 'package:aquaspot_postventa/features/tickets/presentation/pages/inconsistencias_trazabilidad_page.dart';
import 'package:aquaspot_postventa/core/utils/constants.dart' show esAdministradorMaestro;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/auth_bloc.dart';
import '../bloc/auth_event.dart';
import '../bloc/auth_state.dart';
import '../../domain/entities/usuario_entity.dart';
import '../../../tickets/presentation/pages/creacion_ticket_page.dart';
import '../../../tickets/presentation/pages/historial_tickets_page.dart';
import '../../../tickets/presentation/pages/bandeja_evaluaciones_page.dart';
import '../../../tickets/presentation/pages/bandeja_recepcion_page.dart';
import '../../../tickets/presentation/pages/biblioteca_documentos_page.dart';
import '../../../../core/enum/rol_usuario.dart';
import '../pages/registro_usuario_page.dart';

class MainMenuPage extends StatefulWidget {
  const MainMenuPage({super.key});

  @override
  State<MainMenuPage> createState() => _MainMenuPageState();
}

class _MainMenuPageState extends State<MainMenuPage> {
  int _selectedIndex = 0;

  void _logout() {
    context.read<AuthBloc>().add(CerrarSesionEvent());
  }

 @override
  Widget build(BuildContext context) {
    return BlocConsumer<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is Unauthenticated) {
          Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
        }
      },
      builder: (context, state) {
        if (state is! Authenticated) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }

        final operador = state.usuario;
        final bool isAdmin = operador.rol == RolUsuario.admin;
        final bool esTecnico = operador.rol == RolUsuario.tecnico;

        // ✅ EL MULTIPLEXOR DE VISTAS 
        // Para técnicos internos, solo se habilita el módulo de recepción sin historial
        final List<Widget> modulosHMI = [
          _InicioView(operador: operador),
          if (!esTecnico) const HistorialTicketsPage(),
        ];

      return Scaffold(
          backgroundColor: const Color(0xFFF4F7F6),
          appBar: AppBar(
            backgroundColor: Colors.white,
            elevation: 0,
            title: Text(
              esTecnico
                  ? "Recepción Bodega - Aquaspot"
                  : (_selectedIndex == 1 ? "Panel de Historial" : "Aquaspot"),
              style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
            ),
            actions: [
              // 🚪 Botón directo de cerrar sesión para técnicos
              if (esTecnico)
                IconButton(
                  icon: const Icon(Icons.logout, color: Colors.red),
                  tooltip: 'Cerrar Sesión',
                  onPressed: _logout,
                ),

              // ⚙️ COMPUERTA LÓGICA: Acceso restringido a Comerciales y Administradores
              if (operador.rol.name.toLowerCase() == 'comercial' || isAdmin)
                IconButton(
                  icon: const Icon(Icons.person_add_alt_1, color: Colors.black54), // Color atenuado para no ser invasivo
                  tooltip: 'Registrar Cliente',
                  onPressed: () async {
                    // 🚀 DISPARO DEL BOTTOM SHEET (USANDO EL MÉTODO ESTÁTICO CORREGIDO)
                    // Esto evita el ProviderNotFoundException al inyectar su propio BLoC.
                    await RegistroClienteBottomSheet.show(context);
                  },
                ),
                
              if (!esTecnico)
                IconButton(icon: const Icon(Icons.notifications_none, color: Colors.black), onPressed: () {}),
              Padding(
                padding: const EdgeInsets.only(right: 16.0),
                child: CircleAvatar(
                  backgroundColor: const Color(0xFF005A9C),
                  child: Text(operador.email.isNotEmpty ? operador.email[0].toUpperCase() : 'U', style: const TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
          // ✅ EL CONMUTADOR
          body: IndexedStack(
            index: esTecnico ? 0 : _selectedIndex,
            children: modulosHMI,
          ),
          bottomNavigationBar: esTecnico
              ? SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                    child: SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.logout, size: 20),
                        label: const Text(
                          'Cerrar Sesión',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red.shade700,
                          foregroundColor: Colors.white,
                          elevation: 2,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                        onPressed: _logout,
                      ),
                    ),
                  ),
                )
              : BottomNavigationBar(
            currentIndex: _selectedIndex,
            selectedItemColor: const Color(0xFF005A9C),
            unselectedItemColor: Colors.grey,
            onTap: (index) {
              // 1. Condición de salida (Acción sin cambio de vista)
              if (index == 2) {
                _logout();
                return; // <-- CRÍTICO: Abortamos la ejecución aquí. El estado no se toca.
              }

              // 2. Disparos de eventos específicos por módulo
              if (index == 1) {
                // DISPARO DE ORDEN DE RECARGA GLOBAL
                context.read<TicketBloc>().add(
                  const ObtenerHistorialTicketsEvent(segmento: SegmentoOperativo.ninguno)
                );
              }

              // 3. Mutación de estado controlada (Solo llegará aquí si index es 0 o 1)
              setState(() {
                _selectedIndex = index;
              });
            },
            items: const [
              BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Inicio'),
              BottomNavigationBarItem(icon: Icon(Icons.history), label: 'Historial'),
              BottomNavigationBarItem(icon: Icon(Icons.exit_to_app), label: 'Salir'),
            ],
          ),
        );
      },
    );
  }
}

// =====================================================================
// SUB-RUTINA 1: PANEL DE INICIO (El Dashboard principal)
// =====================================================================
class _InicioView extends StatelessWidget {
  final UsuarioEntity operador;

  const _InicioView({required this.operador});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Hola, ${operador.rol.name.toUpperCase()}", 
               style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          ..._getModules(context, operador),
        ],
      ),
    );
  }

  List<Widget> _getModules(BuildContext context, UsuarioEntity operador) {
    List<Widget> modules = [];
    final bool isAdmin = operador.rol == RolUsuario.admin;

    // 📚 BIBLIOTECA DE DOCUMENTOS — no disponible para rol técnico
    if (operador.rol != RolUsuario.tecnico) {
      modules.add(_buildCardOption(
        title: 'Biblioteca de Documentos',
        icon: Icons.perm_media_outlined,
        color: Colors.indigo,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BibliotecaDocumentosPage())),
      ));
    }

    // 🔒 Solo la cuenta administradora maestra: cambio de estado de un ticket
    // con motivo obligatorio (queda en la auditoría como "ADMIN: ...").
    if (esAdministradorMaestro(operador.email)) {
      modules.add(_buildCardOption(
        title: 'Modificar Ticket',
        icon: Icons.edit_note,
        color: Colors.deepOrange,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ModificarTicketPage())),
      ));
      modules.add(_buildCardOption(
        title: 'Inconsistencias de Trazabilidad',
        icon: Icons.rule,
        color: Colors.amber.shade800,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const InconsistenciasTrazabilidadPage())),
      ));
    }

    // 🔒 ACCESO EXCLUSIVO PARA SUPER ADMINISTRADORES
    if (isAdmin) {
      modules.add(_buildCardOption(
        title: 'Gestión de Operarios',
        icon: Icons.admin_panel_settings,
        color: Colors.blueGrey, // Color sobrio para módulos administrativos
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RegistroUsuarioPage())),
      ));
    }

    // 🚀 MÓDULOS DE REQUERIMIENTO Y RECEPCIÓN
    if (isAdmin || operador.rol == RolUsuario.requerimiento || operador.rol == RolUsuario.supervisor) {
      modules.add(_buildCardOption(
        title: 'Crear Ticket',
        icon: Icons.add_box,
        color: Colors.blue,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CreacionTicketPage())),
      ));
    }

    if (isAdmin || operador.rol == RolUsuario.supervisor || operador.rol == RolUsuario.recepcion ) {
      modules.add(_buildCardOption(
        title: 'Tickets',
        icon: Icons.inventory_outlined, 
        color: Colors.teal, 
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaRecepcionPage())),
      ));
    }

    // 🔧 MÓDULOS TÉCNICOS (Reservados para Supervisión y Administración)
    if (isAdmin || operador.rol == RolUsuario.supervisor) {
      modules.add(_buildCardOption(
        title: 'Recepción del Guabo',
        icon: Icons.car_rental,
        color: Colors.lightBlue,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaRecepcionGuaboPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Evaluaciones Técnicas',
        icon: Icons.handyman,
        color: Colors.orange,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaEvaluacionesPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Proceso de trabajo',
        icon: Icons.toll,
        color: Colors.orange.shade800,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaTrabajosPage())),
      ));
    }

    // 📦 MÓDULO DE RECEPCIÓN EN BODEGA
    if (isAdmin ||
        operador.rol == RolUsuario.tecnico ||
        operador.rol == RolUsuario.supervisor) {
      modules.add(_buildCardOption(
        title: 'Recepción Bodega',
        icon: Icons.assignment_turned_in_outlined,
        color: const Color(0xFF00796B),
        onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const BandejaRecepcionBodegaPage())),
      ));
    }

    // 📋 MÓDULOS DE SUPERVISIÓN
    if (isAdmin || operador.rol == RolUsuario.supervisor) {
      modules.add(_buildCardOption(
        title: 'Revisión de garantias',
        icon: Icons.perm_contact_cal_outlined,
        color: Colors.green,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaRevisionesGarantiasPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Catálogo de Actividades y Repuestos',
        icon: Icons.menu_book,
        color: const Color(0xFF005A9C),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const GestionCatalogoActividadesPage())),
      ));

      // 🔎 Códigos del plan maestro vs inventario (el supervisor de un
      // equipo solo ve y corrige el suyo).
      modules.add(_buildCardOption(
        title: 'Revisión de Códigos del Plan Maestro',
        icon: Icons.fact_check_outlined,
        color: const Color(0xFF00796B),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RevisionCodigosPlanMaestroPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Catálogo de Técnicos',
        icon: Icons.badge_outlined,
        color: const Color(0xFF003057),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const GestionTecnicosPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Métricas de Fallas',
        icon: Icons.troubleshoot_outlined,
        color: Colors.blueGrey.shade700,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const GestionMetricasFallasPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Agregar Fallas a Tickets Antiguos',
        icon: Icons.playlist_add_check_circle_outlined,
        color: Colors.deepOrange,
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaFallasPendientesPage())),
      ));
    }

    // 💼 MÓDULOS COMERCIALES
    if (isAdmin || operador.rol == RolUsuario.comercial) {
      modules.add(_buildCardOption(
        title: 'Gestión y Edición de Clientes',
        icon: Icons.people_alt,
        color: const Color(0xFF005A9C), 
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const GestionClientesPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Crear proforma',
        icon: Icons.business_center,
        color: Colors.green, 
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaComercialPage())),
      ));
      
      modules.add(_buildCardOption(
        title: 'Proformas enviadas',
        icon: Icons.access_alarm,
        color: Colors.blue, 
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaProformasEnviadasPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Validación entregas comercial',
        icon: Icons.access_alarm,
        color: Colors.blue, 
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaValidacionFacturacionPage())),
      ));

    modules.add(_buildCardOption(
        title: 'Entrega y facturación',
        icon: Icons.access_alarm,
        color: Colors.blue, 
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaEntregasPage())),
      ));
    }

    // 💰 MÓDULOS DE COSTOS
    if (isAdmin || operador.rol == RolUsuario.costos) {
      modules.add(_buildCardOption(
        title: 'Crear proyecto',
        icon: Icons.account_balance_wallet, 
        color: Colors.orange[800]!, 
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaCostosPage())),
      ));
    }

    // 🛒 MÓDULOS DE COMPRAS Y BODEGA
    if (isAdmin || operador.rol == RolUsuario.compras) {
      modules.add(_buildCardOption(
        title: 'Compras',
        icon: Icons.account_balance_wallet, 
        color: Colors.orange[800]!, 
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaComprasPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Validación Bodega (Compras)',
        icon: Icons.factory, 
        color: Colors.blue[800]!, 
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaBodegaPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Inventario y Stock Bodega',
        icon: Icons.inventory_2_outlined,
        color: const Color(0xFF2E7D32),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const GestionStockBodegaPage())),
      ));
    }

    // 📦 MÓDULOS DE BODEGA / DESPACHO
    if (isAdmin || operador.rol == RolUsuario.bodega) {
      modules.add(_buildCardOption(
        title: 'Despacho Bodega',
        icon: Icons.local_shipping_outlined,
        color: const Color(0xFF005A9C),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BandejaDespachoBodegaPage())),
      ));

      modules.add(_buildCardOption(
        title: 'Inventario y Stock Bodega',
        icon: Icons.inventory_2_outlined,
        color: const Color(0xFF2E7D32),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const GestionStockBodegaPage())),
      ));
    }

    return modules;
  } 

  Widget _buildCardOption({required String title, required IconData icon, required Color color, required VoidCallback onTap}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: Icon(icon, color: color, size: 30),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onTap,
      ),
    );
  }
}