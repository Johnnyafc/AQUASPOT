// lib/features/auth/data/datasources/auth_remote_datasource.dart

import 'package:aquaspot_postventa/core/enum/segmento_operativo.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../domain/entities/usuario_entity.dart';
import '../../../../../core/errors/failures.dart';
import '../../../../core/enum/rol_usuario.dart';

abstract class AuthRemoteDataSource {
  Future<UsuarioEntity> verificarSesion();
  Future<UsuarioEntity> iniciarSesion(String email, String password);
Future<void> guardarPerfilUsuario({
    required String uid,
    required String nombre,
    required String email,
    required SegmentoOperativo segmento,
    required RolUsuario rol,
  });
}
  


class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final FirebaseAuth firebaseAuth;
  final FirebaseFirestore firestore;

  AuthRemoteDataSourceImpl({
    required this.firebaseAuth,
    required this.firestore,
  });

  // =====================================================================
  // ⚙️ DECODIFICADORES DE SEÑALES (Mapeo de strings inseguros a Enums)
  // =====================================================================
  
  RolUsuario _mapearRol(String rolString) {
    final clean = rolString
        .toLowerCase()
        .trim()
        .replaceAll('á', 'a')
        .replaceAll('é', 'e')
        .replaceAll('í', 'i')
        .replaceAll('ó', 'o')
        .replaceAll('ú', 'u');

    switch (clean) {
      case 'requerimiento':
        return RolUsuario.requerimiento;
      case 'tecnico':
      case 'tecnicorecepcionbodega':
      case 'tecnico_recepcion_bodega':
      case 'tecnico_recepcion':
      case 'tecnico_bodega':
        return RolUsuario.tecnico;
      case 'supervisor':
      case 'supervision':
        return RolUsuario.supervisor;
      case 'recepcion':
      case 'recepcion_guabo':
      case 'recepcionguabo':
        return RolUsuario.recepcion;
      case 'admin':
      case 'administrador':
      case 'administracion':
        return RolUsuario.admin;
      case 'comercial':
        return RolUsuario.comercial;
      case 'costos':
        return RolUsuario.costos;
      case 'compras':
        return RolUsuario.compras;
      case 'bodega':
      case 'despacho':
        return RolUsuario.bodega;
      case 'procesotrabajo':
      case 'proceso_trabajo':
      case 'taller':
        return RolUsuario.procesoTrabajo;
      default:
        return RolUsuario.desconocido;
    }
  }

  // ✅ NUEVO DECODIFICADOR: Lee el segmento de Firestore de forma segura
  SegmentoOperativo _mapearSegmento(String? segmentoStr) {
    if (segmentoStr == null || segmentoStr.trim().isEmpty) {
      return SegmentoOperativo.ninguno; // Válvula de seguridad (Fail-Safe)
    }

    switch (segmentoStr.toLowerCase().trim()) {
      case 'contador': 
        return SegmentoOperativo.contador;
      case 'cosechadora': 
        return SegmentoOperativo.cosechadora;
      case 'caracol': 
        return SegmentoOperativo.caracol;
      case 'general': 
        return SegmentoOperativo.general;
      default: 
        return SegmentoOperativo.ninguno;
    }
  }

  // =====================================================================
  // 🚀 LÓGICA DE AUTENTICACIÓN
  // =====================================================================

@override
  Future<void> guardarPerfilUsuario({
    required String uid,
    required String nombre,
    required String email,
    required SegmentoOperativo segmento,
    required RolUsuario rol,
  }) async {
    try {
      // 📡 Comando de escritura en Firestore (La ruta 'usuarios' es el nodo de almacenamiento)
      await firestore.collection('usuarios').doc(uid).set({
        'uid': uid,
        'nombre': nombre,
        'email': email,
        'segmento': segmento.name, // Convertimos el Enum a String para el JSON
        'rol': rol.name,           // Convertimos el Enum a String
        'fechaCreacion': FieldValue.serverTimestamp(), // Telemetría industrial importante
      });

      // 🔗 ENLACE AUTOMÁTICO: Si es un técnico creado por Admin, se registra en catalogo_tecnicos como ENROLADO
      if (rol == RolUsuario.tecnico) {
        await firestore.collection('catalogo_tecnicos').doc(uid).set({
          'id': uid,
          'nombre': nombre,
          'rol': 'Técnico Enrolado',
          'activo': true,
          'esExterno': false,
          'usuarioUid': uid,
          'fechaRegistro': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }
    } catch (e) {
      // Si la escritura falla, lanzamos una excepción para que el Repositorio la capture
      throw Exception('Fallo crítico en la escritura de base de datos: $e');
    }
  }

  

  @override
  Future<UsuarioEntity> iniciarSesion(String email, String password) async {
    try {
      // 1. Validamos la huella dactilar (Email y Clave)
      final userCredential = await firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = userCredential.user;
      if (user == null) {
        throw ServerFailure('Fallo catastrófico en la autenticación del motor.');
      }

      // 2. Buscamos el perfil de seguridad en Firestore usando el UID
      final docSnapshot = await firestore.collection('usuarios').doc(user.uid).get();

      if (!docSnapshot.exists) {
        await firebaseAuth.signOut(); 
        throw ServerFailure('Operador sin perfil de seguridad asignado en el sistema.');
      }

      final data = docSnapshot.data()!;
      
      // 3. Extraemos y decodificamos los datos
      final rol = _mapearRol(data['rol'] ?? '');
      // ✅ Pasamos la señal cruda por el decodificador de segmento
      final segmento = _mapearSegmento(data['segmento'] as String?);

      if (rol == RolUsuario.desconocido) {
        await firebaseAuth.signOut();
        throw ServerFailure('Nivel de acceso corrupto o no reconocido.');
      }

      final String nombreCapturado = data['nombre'] ?? 'Operario Desconocido';

      // 4. Emitimos la tarjeta de identificación válida con los 5 parámetros obligatorios
      return UsuarioEntity(
        uid: user.uid,
        email: user.email!,
        nombre: nombreCapturado, 
        rol: rol,
        segmento: segmento, // ✅ Cable de telemetría conectado correctamente
      );
      
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found' || e.code == 'wrong-password' || e.code == 'invalid-credential') {
        throw ServerFailure('Credenciales denegadas. Operador no autorizado.');
      }
      throw ServerFailure(e.message ?? 'Error de protocolo en FirebaseAuth.');
    } catch (e) {
      throw ServerFailure('Fallo interno del lector RFID: $e');
    }
  }

  // ✅ NUEVA SUBRUTINA: ARRANQUE EN FRÍO (ANTI-F5)
  @override
  Future<UsuarioEntity> verificarSesion() async {
    try {
      // 1. Forzamos la memoria persistente
      await firebaseAuth.setPersistence(Persistence.LOCAL);
      
      // 2. Revisamos el caché interno
      final user = firebaseAuth.currentUser;
      if (user != null) {
        // 3. Buscamos el perfil maestro en Firestore
        final docSnapshot = await firestore.collection('usuarios').doc(user.uid).get();
        if (docSnapshot.exists && docSnapshot.data() != null) {
          final data = docSnapshot.data()!;
          final rol = _mapearRol(data['rol'] ?? '');
          final segmento = _mapearSegmento(data['segmento'] as String?);

          if (rol == RolUsuario.desconocido) {
            await firebaseAuth.signOut();
            throw ServerFailure('Nivel de acceso corrupto tras recarga.');
          }

          return UsuarioEntity(
            uid: user.uid, email: user.email!, nombre: data['nombre'] ?? 'Operario', 
            rol: rol, segmento: segmento, 
          );
        } else {
          throw ServerFailure('Perfil no encontrado en base de datos al recargar.');
        }
      } else {
        throw ServerFailure('No hay sesión en caché.');
      }
    } catch (e) {
      throw ServerFailure('Fallo de lectura en memoria: $e');
    }
  }
}


  
