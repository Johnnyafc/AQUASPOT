# Aquaspot Postventa — Contexto del proyecto

App Flutter/Firebase de gestión de postventa (tickets de reparación, garantía,
venta de repuestos, etc.) de Aquaspot. Arquitectura limpia por features
(`lib/features/<feature>/{data,domain,presentation}`), BLoC para estado,
Firestore como backend. Rama de trabajo actual: `aquaspot_optimizado`.

Este archivo resume el contexto acumulado en una sesión larga de trabajo con
Claude (vía Cowork) para que una sesión de Claude Code en esta misma carpeta
arranque con la misma memoria, sin tener que repetir todo desde cero.

## Reglas fijas (NO negociables, confirmadas explícitamente por el dueño del proyecto)

1. **Nunca hacer `git commit` sin una autorización explícita e inequívoca en
   ese mismo turno.** No asumir que "implementar" implica "commitear". Esperar
   a que el usuario pruebe el cambio y confirme antes de ofrecer commitear.
2. **Nunca editar o escribir código sin aprobación explícita en ese turno.**
   Para cambios de alcance abierto o decisiones de arquitectura, primero
   plantear el plan en palabras y esperar confirmación antes de tocar archivos.
3. **Problema conocido de fin de línea (CRLF/LF):** ~242 archivos aparecen
   como "modificados" en `git status` porque el git de este entorno no tiene
   `core.autocrlf` configurado igual que el git de Windows del usuario. **Nunca
   tocar, normalizar, ni hacer `git add -A` / `git add .`** — eso arrastraría
   esos falsos positivos. Al hacer `git add`, listar siempre los archivos
   exactos que de verdad se editaron.
4. Cada commit debe ser independiente y descriptivo; nunca usar `--amend`
   salvo pedido explícito.
5. Identidad git local ya configurada en este repo (NO global):
   `user.name = Johnnyafc`, `user.email = johfcede@espol.edu.ec` (coincide
   con el autor real de los commits anteriores del proyecto).
6. **Flutter SÍ está disponible en Claude Code en la máquina del usuario**
   (`C:\srclutter`): verificar siempre con `flutter analyze` (0 errores;
   hay ~149 avisos previos) y `flutter test`. Las Cloud Functions se compilan
   con `npm run build` en `functions/`; el despliegue lo hace el usuario.
   (En Cowork / la nube NO hay Flutter.)
7. Toda edición debe ser quirúrgica: leer el archivo antes de tocarlo,
   verificar que el string a reemplazar es único antes de escribir, revisar
   balance de llaves/paréntesis/corchetes después, y revisar el `git diff`
   para confirmar que el cambio quedó aislado a lo pedido.
8. **Respaldo antes de cada cambio:** copiar cada archivo a tocar en
   `Claude outputs/respaldos/<fecha>_antes_<tema>/<ruta>.respaldo` (la
   extensión `.respaldo` evita que Dart lo compile) junto con un
   `RESTAURAR.ps1` que los devuelve a su lugar.
9. **Plantear primero.** El usuario aprueba con "actúa", "procede",
   "implementa". "Solo eso" = no agregar nada más. Si dice "plantea" o "no
   hagas nada", solo se plantea.
10. Cuenta administradora maestra: `adminmaster@aquaspot.ec`
    (`correoAdministradorMaestro` en `lib/core/utils/constants.dart`): única
    que ve "Modificar Ticket" e "Inconsistencias de Trazabilidad".

## Estado del repositorio (actualizado 2026-10-07)

Commit más reciente: `0f1c1f0`. **Todo lo trabajado del 05 al 07/10/2026
está SIN commitear** (pendiente de prueba y autorización del usuario).

**El detalle completo de esa sesión está en
`Claude outputs/CONTEXTO_SESION_2026-10-05_al_07.md`** — leerlo antes de
continuar. Resumen:

- **Venta de Repuesto** (módulo en desarrollo): fases 1–3 hechas (creación
  con contador y ruteo por stock/asistencia, Cloud Functions, cotización de
  Compras con estado nuevo `cotizandoRepuesto`). Pendientes: fases 4
  (Proforma reducida) y 5 (Evaluación de venta).
- **Bodega**: "Validación simple" en Despacho para tickets atascados en
  `bodega`; notificaciones push a Bodega (Cloud Functions, sin desplegar).
- **Trazabilidad por proceso**: eventos de auditoría con `proceso` / `hito`
  / `habilita` (`core/enum/proceso_auditoria.dart`);
  `TiemposPorProcesoService` mide en paralelo (tickets nuevos) o por texto
  (antiguos), promedio por ticket, tramos de 0 min cuentan.
- **Admin**: tarjetas "Modificar Ticket" (cambio de estado auditado como
  `ADMIN: CAMBIO FORZADO…`) e "Inconsistencias de Trazabilidad" (reglas en
  `InconsistenciasTrazabilidadService`, marca "Revisado" en
  `ticket.inconsistenciasRevisadas`).
- **Dashboard**: filtros nuevos (Requerimiento, Estado con 15 estados,
  Garantía solo Máquina nueva/Servicio), KPIs de reclamos vs garantías
  aprobadas, días promedio solo finalizados, diagnóstico de fallas,
  dictamen de garantía (Aprobada / Rechazada por etiqueta de auditoría /
  Sin dictamen), donas interactivas, limpieza de código sin uso.
- **Reclamo de garantía** = `tipoRequerimiento == reclamoGarantia` **o**
  dictamen de garantía en la auditoría (`TicketEntity.esReclamoDeGarantia`).
- Respaldos de cada cambio en `Claude outputs/respaldos/`.

Pendientes generales: commits por tema, desplegar functions, Venta fases 4–5,
regla "datos de garantía cruzados", limpieza de código muerto, inventario
por bodega, contraseña SMTP en `functions/src/index.ts` (mover a Secret
Manager).
